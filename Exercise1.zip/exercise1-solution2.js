//Only supported in some browsers
const main = () => {
    const controller = new AbortController();
        const request =
        {
            targets: [
                "https://jsonplaceholder.typicode.com/todos",
                "https://jsonplaceholder.typicode.com/comments",
                "https://jsonplaceholder.typicode.com/posts"
            ],
            signal: controller.signal
        }

        const timeoutId = setTimeout(() => {
            controller.abort();
        }, 3000);

        fetchResources(request).then((result) => {
            clearTimeout(timeoutId);

            const content = result;
            const contentLength = result.join("").length;

            console.log(content);
            console.log(contentLength);
        }).catch((err) => {
            //timeout or some other errors
            console.log(err);
        });
    }

    const fetchResources = async (request) => {
        const result = await Promise.all(
            request.targets.map(url => fetchResource(url, { signal: request.signal }))
        );

        return result;
    }

    const fetchResource = async (url, opts) => {
        const response = await fetch(url, { ...opts });
        return await response.text();
    }