const main = () => {
    const request =
    {
        targets: [
            "https://jsonplaceholder.typicode.com/todos",
            "https://jsonplaceholder.typicode.com/comments",
            "https://jsonplaceholder.typicode.com/posts"
        ],
        timeout: 3000
    }

    fetchResources(request).then((res) => {
        const content = res;
        const contentLength = res.join("").length;

        console.log(content);
        console.log(contentLength);
    }).catch((err) => {
        //timeout or some other errors
        console.log(err);
    });
}


const fetchResources = async (request) => {
    const result = await Promise.all(
        request.targets.map(url => fetchExt(fetch(url), request.timeout))
    );
    return result;
}

const fetchExt = (promise, timeout) => {
    return new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
            reject(new Error("timeout"))
        }, timeout);
        
        promise.then(res => res.text()).then((text) => {
            clearTimeout(timeoutId);
            resolve(text);
        }).catch((err) => {
            clearTimeout(timeoutId);
            reject(err);
        });
    });
}