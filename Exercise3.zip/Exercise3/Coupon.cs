﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise3
{
    public class Coupon
    {
    }
}
