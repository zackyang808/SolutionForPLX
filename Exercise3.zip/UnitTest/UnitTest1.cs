using Exercise3;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace UnitTest
{
    public class CouponManagerTest
    {
        private readonly Mock<ILogger> _logger;
        private readonly Mock<ICouponProvider> _couponProvider;
        private readonly CouponManager _couponManager;

        public CouponManagerTest()
        {
            _logger = new Mock<ILogger>();
            _couponProvider = new Mock<ICouponProvider>();
            _couponProvider.Setup(x => x.Retrieve(It.IsAny<Guid>())).ReturnsAsync(new Coupon()).Verifiable();
            _couponManager = new CouponManager(_logger.Object, _couponProvider.Object);
        }

        [Fact]
        public void CanRedeemCoupon_EvaluatorsIsNull_ShouldThrowArgumentNullException()
        {
            //Arrange
            Guid couponId = Guid.NewGuid();
            Guid userId = Guid.NewGuid();
            IEnumerable<Func<Coupon, Guid, bool>> evaluators = null;

            //Assert
            Assert.ThrowsAsync<ArgumentNullException>(() => _couponManager.CanRedeemCoupon(couponId, userId, evaluators));
        }

        [Fact]
        public void CanRedeemCoupon_CouponIsNull_ShouldThrowKeyNotFoundException()
        {
            //Arrange
            Guid couponId = Guid.NewGuid();
            Guid userId = Guid.NewGuid();
            IEnumerable<Func<Coupon, Guid, bool>> evaluators = null;
            _couponProvider.Setup(x => x.Retrieve(It.IsAny<Guid>())).ReturnsAsync((Coupon)null);

            //Assert          
            Assert.ThrowsAsync<ArgumentNullException>(() => _couponManager.CanRedeemCoupon(couponId, userId, evaluators));
        }


        [Fact]
        public async Task CanRedeemCoupon_NoEvaluators_ShouldReturnTrue()
        {
            //Arrange
            Guid couponId = Guid.NewGuid();
            Guid userId = Guid.NewGuid();
            IEnumerable<Func<Coupon, Guid, bool>> evaluators = new List<Func<Coupon, Guid, bool>>();

            //Act
            var actual = await _couponManager.CanRedeemCoupon(couponId, userId, evaluators);

            //Assert
            _couponProvider.Verify(x => x.Retrieve(It.IsAny<Guid>()), Times.Once);
            Assert.True(actual);
        }

        [Theory]
        [MemberData(nameof(DataForCanRedeemCoupon))]
        public async Task CanRedeemCoupon_ShouldReturnAsExpected(IEnumerable<Func<Coupon, Guid, bool>> evaluators, bool expected)
        {
            //Arrange
            Guid couponId = Guid.NewGuid();
            Guid userId = Guid.NewGuid();

            //Act
            var actual = await _couponManager.CanRedeemCoupon(couponId, userId, evaluators);

            //Assert
            _couponProvider.Verify(x => x.Retrieve(It.IsAny<Guid>()), Times.Once);
            Assert.Equal(expected, actual);
        }

        public static IEnumerable<object[]> DataForCanRedeemCoupon =>
            new List<object[]>
            {
                new object[]
                {
                    new List<Func<Coupon, Guid, bool>>
                    {
                        (coupon,id)=>true,
                        (coupon,id)=>true,
                    },
                    true
                },
                new object[]
                {
                    new List<Func<Coupon, Guid, bool>>
                    {
                        (coupon,id)=>true,
                        (coupon,id)=>false,
                    },
                    true
                },
                new object[]
                {
                    new List<Func<Coupon, Guid, bool>>
                    {
                        (coupon,id)=>false,
                        (coupon,id)=>true,
                    },
                    true
                },
                new object[]
                {
                    new List<Func<Coupon, Guid, bool>>
                    {
                        (coupon,id)=>false,
                        (coupon,id)=>false,
                    },
                    false
                },
            };            
    }
}
